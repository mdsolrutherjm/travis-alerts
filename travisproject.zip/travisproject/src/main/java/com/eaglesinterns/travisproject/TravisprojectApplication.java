package com.eaglesinterns.travisproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravisprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravisprojectApplication.class, args);
	}
}
